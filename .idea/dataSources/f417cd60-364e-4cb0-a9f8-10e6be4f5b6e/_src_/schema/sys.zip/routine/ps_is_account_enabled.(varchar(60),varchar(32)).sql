CREATE FUNCTION ps_is_account_enabled(in_host VARCHAR(60), in_user VARCHAR(32))
  RETURNS ENUM ('YES', 'NO')
  BEGIN RETURN IF(EXISTS(SELECT 1 FROM performance_schema.setup_actors WHERE (`HOST` = '%' OR in_host LIKE `HOST`) AND (`USER` = '%' OR `USER` = in_user) AND (`ENABLED` = 'YES') ), 'YES', 'NO' ); END;
